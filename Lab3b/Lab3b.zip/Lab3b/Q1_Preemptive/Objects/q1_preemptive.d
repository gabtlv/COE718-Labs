.\objects\q1_preemptive.o: Q1_Preemptive.c
.\objects\q1_preemptive.o: C:\Users\simpl\AppData\Local\Arm\Packs\ARM\CMSIS\5.7.0\CMSIS\RTOS\RTX\INC\cmsis_os.h
.\objects\q1_preemptive.o: C:\Keil_v5\ARM\ARM_Compiler_5.06u7\Bin\..\include\stdint.h
.\objects\q1_preemptive.o: C:\Keil_v5\ARM\ARM_Compiler_5.06u7\Bin\..\include\stddef.h
.\objects\q1_preemptive.o: build_cfg.h
.\objects\q1_preemptive.o: demo_io.h
