param([string]$Name, [int]$X = -1, [int]$Y = -1, [int]$W = -1, [int]$H = -1)
# Saves a PNG of the front uVision window (or a region of it, in window-relative pixels).
# Retries while the dark Claude app window is covering the right side of the screen.
Add-Type -AssemblyName System.Drawing
Add-Type @"
using System; using System.Runtime.InteropServices;
public class W32 {
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int L, T, R, B; }
  [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
  [DllImport("dwmapi.dll")] public static extern int DwmGetWindowAttribute(IntPtr h, int a, out RECT r, int s);
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
}
"@
[W32]::SetProcessDPIAware() | Out-Null
$hwnd = [W32]::GetForegroundWindow()
$r = New-Object W32+RECT
[W32]::DwmGetWindowAttribute($hwnd, 9, [ref]$r, 16) | Out-Null
$wx = $r.L; $wy = $r.T; $ww = $r.R - $r.L; $wh = $r.B - $r.T
if ($X -ge 0) { $wx += $X; $wy += $Y; $ww = $W; $wh = $H }

function Overlay-Present {
  $full = New-Object System.Drawing.Bitmap 2880, 1824
  $g = [System.Drawing.Graphics]::FromImage($full)
  $g.CopyFromScreen(0, 0, 0, 0, $full.Size); $g.Dispose()
  $dark = 0
  foreach ($p in @(@(2000,300), @(2700,300), @(2400,700), @(2000,1100), @(2700,1100), @(2400,1400))) {
    $c = $full.GetPixel($p[0], $p[1]); if ($c.R -lt 60 -and $c.G -lt 60 -and $c.B -lt 60) { $dark++ }
  }
  $full.Dispose()
  return ($dark -ge 5)
}
$tries = 0
while ((Overlay-Present) -and $tries -lt 40) { Start-Sleep -Milliseconds 500; $tries++ }

$bmp = New-Object System.Drawing.Bitmap $ww, $wh
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.CopyFromScreen($wx, $wy, 0, 0, $bmp.Size)
$out = Join-Path $PSScriptRoot ($Name + '.png')
$bmp.Save($out, [System.Drawing.Imaging.ImageFormat]::Png)
$g.Dispose(); $bmp.Dispose()
"saved $out ($ww x $wh) after $tries retries; window at $($r.L),$($r.T) size $($r.R-$r.L)x$($r.B-$r.T)"
