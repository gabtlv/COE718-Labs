.\objects\glcd_spi_lpc1700.o: GLCD_SPI_LPC1700.c
.\objects\glcd_spi_lpc1700.o: build_cfg.h
