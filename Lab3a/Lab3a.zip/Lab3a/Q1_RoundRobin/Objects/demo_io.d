.\objects\demo_io.o: demo_io.c
.\objects\demo_io.o: build_cfg.h
