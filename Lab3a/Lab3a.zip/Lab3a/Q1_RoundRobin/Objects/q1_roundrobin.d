.\objects\q1_roundrobin.o: Q1_RoundRobin.c
.\objects\q1_roundrobin.o: C:\Users\simpl\AppData\Local\Arm\Packs\ARM\CMSIS\5.7.0\CMSIS\RTOS\RTX\INC\cmsis_os.h
.\objects\q1_roundrobin.o: C:\Keil_v5\ARM\ARM_Compiler_5.06u7\Bin\..\include\stdint.h
.\objects\q1_roundrobin.o: C:\Keil_v5\ARM\ARM_Compiler_5.06u7\Bin\..\include\stddef.h
.\objects\q1_roundrobin.o: build_cfg.h
.\objects\q1_roundrobin.o: demo_io.h
