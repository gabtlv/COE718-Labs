.\objects\part2_marspathfinder.o: Part2_MarsPathfinder.c
.\objects\part2_marspathfinder.o: C:\Users\simpl\AppData\Local\Arm\Packs\ARM\CMSIS\5.7.0\CMSIS\RTOS\RTX\INC\cmsis_os.h
.\objects\part2_marspathfinder.o: C:\Keil_v5\ARM\ARM_Compiler_5.06u7\Bin\..\include\stdint.h
.\objects\part2_marspathfinder.o: C:\Keil_v5\ARM\ARM_Compiler_5.06u7\Bin\..\include\stddef.h
