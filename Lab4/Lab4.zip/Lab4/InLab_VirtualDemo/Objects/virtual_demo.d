.\objects\virtual_demo.o: virtual_demo.c
.\objects\virtual_demo.o: osObjects.h
.\objects\virtual_demo.o: C:\Users\simpl\AppData\Local\Arm\Packs\ARM\CMSIS\5.7.0\CMSIS\RTOS\RTX\INC\cmsis_os.h
.\objects\virtual_demo.o: C:\Keil_v5\ARM\ARM_Compiler_5.06u7\Bin\..\include\stdint.h
.\objects\virtual_demo.o: C:\Keil_v5\ARM\ARM_Compiler_5.06u7\Bin\..\include\stddef.h
.\objects\virtual_demo.o: C:\Keil_v5\ARM\ARM_Compiler_5.06u7\Bin\..\include\stdio.h
.\objects\virtual_demo.o: C:\Keil_v5\ARM\ARM_Compiler_5.06u7\Bin\..\include\math.h
.\objects\virtual_demo.o: Board_LED.h
